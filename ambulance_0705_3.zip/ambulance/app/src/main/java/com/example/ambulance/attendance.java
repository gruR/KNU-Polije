package com.example.ambulance;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class attendance extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);
        findViewById(R.id.yes).setOnClickListener(this);
        findViewById(R.id.no).setOnClickListener(this);

    }
    @Override
    public void onClick(View view)
    {
        switch(view.getId())
        {
            case R.id.yes:
                Intent intent = new Intent(this,driver_waiting.class);
                startActivity(intent);
                break;
            case R.id.no:
              /*  ActivityCompat.finishAffinity(this);
                System.runFinalization();
                System.exit(0);
        */
                finish();
        }

    }
}
