package com.example.ambulance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class login extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        findViewById(R.id.login_btn).setOnClickListener(this);
        findViewById(R.id.signup_btn).setOnClickListener(this);
    }
    @Override
    public void onClick(View view)
    {
        switch(view.getId())
        {
            case R.id.login_btn:
                Intent intent = new Intent(this,attendance.class);
                startActivity(intent);
                break;
            case R.id.signup_btn:
                Intent intent2 = new Intent(this,registration.class);
                startActivity(intent2);
        }

    }
}
