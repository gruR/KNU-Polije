package com.example.ambulance;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class user_status extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_status);
    }
}
